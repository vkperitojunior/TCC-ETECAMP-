import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grafico-pontos',
  templateUrl: './grafico-pontos.page.html',
  styleUrls: ['./grafico-pontos.page.scss'],
})
export class GraficoPontosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
