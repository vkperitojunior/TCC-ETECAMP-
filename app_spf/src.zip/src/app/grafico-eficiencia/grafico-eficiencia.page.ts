import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grafico-eficiencia',
  templateUrl: './grafico-eficiencia.page.html',
  styleUrls: ['./grafico-eficiencia.page.scss'],
})
export class GraficoEficienciaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
