import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NavController, MenuController } from '@ionic/angular';
import { ApiService } from '../services/api.service'; 

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {
  menuType: string = 'overlay';
  selectedYear: number = new Date().getFullYear();
  selectedNews: any;
  years: number[] = [2022, 2023, 2024];
  newsList: any[] = [
    { id: 1, title: 'Notícia 1' },
    { id: 2, title: 'Notícia 2' },
    { id: 3, title: 'Notícia 3' },
    { id: 4, title: 'Notícia 4' },
  ];

  showTable: string | null = null;
  DarkMode: boolean = false;

  // Dados que vamos buscar da API
  equipes: any[] = [];
  gincanas: any[] = [];
  noticias: any[] = [];
  temas: any[] = [];
  usuarios: any[] = [];

  @ViewChild('topContent', { static: false }) topContent!: ElementRef;
  @ViewChild('tabelaEquipes', { static: false }) tabelaEquipes!: ElementRef;
  @ViewChild('tabelaPontos', { static: false }) tabelaPontos!: ElementRef;
  @ViewChild('tabelaLocais', { static: false }) tabelaLocais!: ElementRef;
  @ViewChild('tabelaOrganizadores', { static: false }) tabelaOrganizadores!: ElementRef;
  @ViewChild('tabelaGraficoPontos', { static: false }) tabelaGraficoPontos!: ElementRef;
  @ViewChild('tabelaGraficoEficiencia', { static: false }) tabelaGraficoEficiencia!: ElementRef;

  constructor(private navCtrl: NavController, private menuController: MenuController, private apiService: ApiService) {}

  ngOnInit() {
    this.initializeTheme();
    this.loadData(); // Carregar dados da API ao inicializar
  }

  initializeTheme() {
    const darkModeEnabled = document.documentElement.getAttribute('data-theme') === 'dark';
    this.DarkMode = darkModeEnabled;
  }

  toggleDarkMode() {
    this.DarkMode = !this.DarkMode; // Alterna o estado
    document.documentElement.setAttribute('data-theme', this.DarkMode ? 'dark' : 'light');
  }

  scrollToTop() {
    this.topContent.nativeElement.scrollIntoView({ behavior: 'smooth' });
  }

  get modeText() {
    return this.DarkMode ? 'Modo Claro' : 'Modo Escuro';
  }

  fetchYearData() {
    console.log(`Ano Selecionado: ${this.selectedYear}`);
  }

  fetchNewsData() {
    console.log(`ID da Notícia Selecionada: ${this.selectedNews}`);
  }

  toggleTable(tableName: string) {
    this.showTable = this.showTable === tableName ? null : tableName;

    setTimeout(() => {
      this.scrollToTable(tableName);
    }, 200);
  }

  scrollToTable(tableName: string) {
    switch (tableName) {
      case 'equipes':
        this.tabelaEquipes.nativeElement.scrollIntoView({ behavior: 'smooth' });
        break;
      case 'pontos':
        this.tabelaPontos.nativeElement.scrollIntoView({ behavior: 'smooth' });
        break;
      case 'locais':
        this.tabelaLocais.nativeElement.scrollIntoView({ behavior: 'smooth' });
        break;
      case 'organizadores':
        this.tabelaOrganizadores.nativeElement.scrollIntoView({ behavior: 'smooth' });
        break;
      case 'grafico_pontos':
        this.tabelaGraficoPontos.nativeElement.scrollIntoView({ behavior: 'smooth' });
        break;
      case 'grafico_eficiencia':
        this.tabelaGraficoEficiencia.nativeElement.scrollIntoView({ behavior: 'smooth' });
        break;
    }
  }

  // Método para carregar dados da API
  loadData() {
    this.apiService.getEquipes().subscribe((data) => {
      this.equipes = data;
      console.log('Equipes:', this.equipes);
    });

    this.apiService.getGincanas().subscribe((data) => {
      this.gincanas = data;
    });

    this.apiService.getNoticias().subscribe((data) => {
      this.noticias = data;
    });

    this.apiService.getTemas().subscribe((data) => {
      this.temas = data;
    });

    this.apiService.getUsuarios().subscribe((data) => {
      this.usuarios = data;
    });
  }

  // Método para navegar para a página de Tarefas
  navigateToTarefas() {
    console.log('Navegando para Tarefas');
    this.navCtrl.navigateRoot('tarefas');
  }

  openMenu() {
    this.menuController.open(); // Abre o menu
  }

  closeMenu() {
    this.menuController.close(); // Fecha o menu
  }
}
